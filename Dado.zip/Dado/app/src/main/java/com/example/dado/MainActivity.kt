package com.example.dado

import android.os.Bundle
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import kotlin.random.Random

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //chama o botão da outra tela e faz ele ativar o sorteio
        val botaoGirar: Button = findViewById(R.id.butao)

        botaoGirar.setOnClickListener {
            sorteio()
        }
    }
    //sorteia um número do dado
    fun sorteio() {
        val numeroSorteado = Random.nextInt(1, 7)

        //saída do número que o dado sorteou
        Toast.makeText(this, "O número que o dado tirou foi: $numeroSorteado", Toast.LENGTH_SHORT).show()


    }
}
